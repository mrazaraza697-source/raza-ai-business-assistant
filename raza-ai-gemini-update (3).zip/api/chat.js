export default async function handler(req, res) {
  if (req.method !== "POST") {
    res.setHeader("Allow", "POST");
    return res.status(405).json({ error: "Method not allowed" });
  }
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) return res.status(500).json({ error: "GEMINI_API_KEY missing in Vercel Environment Variables." });

  const { message, history = [] } = req.body || {};
  if (typeof message !== "string" || !message.trim()) {
    return res.status(400).json({ error: "Please enter a message." });
  }

  const contents = [];
  for (const item of (Array.isArray(history) ? history.slice(-20) : [])) {
    const role = item && item.role === "assistant" ? "model" : "user";
    const content = item && typeof item.content === "string" ? item.content.trim() : "";
    if (content) contents.push({ role, parts: [{ text: content }] });
  }
  contents.push({ role: "user", parts: [{ text: message.trim() }] });

  const model = process.env.GEMINI_MODEL || "gemini-3.8-flash";
  try {
    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`,
      { method: "POST", headers: { "Content-Type": "application/json", "x-goog-api-key": apiKey },
        body: JSON.stringify({ contents }) }
    );
    const data = await response.json();
    if (!response.ok) return res.status(response.status).json({ error: data?.error?.message || `Gemini API error (${response.status}).` });
    const reply = (data?.candidates?.[0]?.content?.parts || []).map(p => p.text || "").join("").trim();
    if (!reply) return res.status(502).json({ error: "Gemini returned no text. Try again." });
    return res.status(200).json({ reply });
  } catch (error) {
    return res.status(500).json({ error: error.message || "Could not connect to Gemini." });
  }
}
